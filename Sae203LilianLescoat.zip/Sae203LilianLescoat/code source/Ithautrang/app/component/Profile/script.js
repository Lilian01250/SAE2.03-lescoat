import { MovieCard } from "../Movie/script.js";

const templateFile = await fetch("./component/Profile/template.html");
const template = await templateFile.text();


let ProfilePage = {};

ProfilePage.format = function (profile, movies) {
  let html = template;

  const avatar = profile.avatar && profile.avatar.trim() !== "" ? profile.avatar : "avatar_vide.jpg";
  html = html.replaceAll("{{name}}", profile.name);
  html = html.replace("{{avatar}}", avatar);

  if (movies.length === 0) {
    html = html.replace("{{cards}}", "<p class='no-movie'>Vous n'avez pas encore de films mis en favoris.</p>");
  } else {
    html = html.replace("{{cards}}", MovieCard.format(movies));
  }

  return html;
};

export { ProfilePage };