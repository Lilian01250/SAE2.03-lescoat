# README

Voici les changements faits sur la base de données au fil des itérations, avec une explication simple de chaque choix.

---

**Itération 1 – Liste des films**

J’ai commencé par importer le fichier `SAE203.sql`, qui a créé deux tables principales :  

- **Category** avec les colonnes `id` (clé primaire auto-incrémentée) et `name` (texte court).  
- **Movie** avec plusieurs colonnes : titre, année, durée, description, réalisateur, catégorie, image, bande-annonce, âge minimum, recommandé.

Les types de données utilisés (comme `VARCHAR`, `TEXT`, `INT`) permettent de stocker toutes les infos nécessaires de manière claire et efficace.

---

**Itération 4 – Regrouper par catégorie**

Pour afficher les films par catégorie, j’ai ajouté une clé étrangère dans la table **Movie** qui pointe vers **Category** (`id_category` → `id`).  

Cela permet d’éviter les erreurs (comme une catégorie inexistante) et d’accélérer les recherches avec un index sur `id_category`.

---

**Itération 5 – Formulaire utilisateur (admin)**

J’ai créé une table **Utilisateur** pour gérer les profils :  

- `id` (clé primaire auto-incrémentée)  
- `name` (nom du profil)  
- `avatar` (image du profil)  
- `age` (date de naissance)

Le champ `age` est de type DATE pour calculer l’âge réel plus tard, utile pour filtrer les films selon l’âge requis.

---

**Itération 9 – Système de favoris**

J’ai ajouté une table **Favorite** pour enregistrer les films favoris de chaque utilisateur :  

- `id_user` (identifiant du profil)  
- `id_movie` (identifiant du film)  
- clé primaire composée des deux champs  
- deux clés étrangères pour relier les films et les profils

Cette table fait le lien entre films et utilisateurs sans doublons, et facilite les recherches.

---

**Itération 11 – Films recommandés**

J’ai ajouté une colonne `recommened` à la table **Movie** (type TINYINT).  

Ce champ vaut 1 si le film est mis en avant, sinon 0. Cela permet de marquer facilement certains films sans alourdir la base.