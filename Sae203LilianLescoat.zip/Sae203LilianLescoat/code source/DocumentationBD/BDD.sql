-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 18 avr. 2025 à 21:57
-- Version du serveur : 8.0.41-0ubuntu0.22.04.1
-- Version de PHP : 8.1.2-1ubuntu2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `SAE203`
--

-- --------------------------------------------------------

--
-- Structure de la table `Category`
--

CREATE TABLE `Category` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `Category`
--

INSERT INTO `Category` (`id`, `name`) VALUES
(1, 'Action'),
(2, 'Comédie'),
(3, 'Drame'),
(4, 'Science-fiction'),
(5, 'Animation'),
(6, 'Thriller'),
(7, 'Horreur'),
(8, 'Aventure'),
(9, 'Fantaisie'),
(10, 'Documentaire');

-- --------------------------------------------------------

--
-- Structure de la table `Favorite`
--

CREATE TABLE `Favorite` (
  `id_user` int DEFAULT NULL,
  `id_movie` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `Favorite`
--

INSERT INTO `Favorite` (`id_user`, `id_movie`) VALUES
(55, 68),
(3, 54),
(3, 17),
(55, 58),
(55, 77),
(55, 62),
(55, 55),
(55, 61),
(55, 7);

-- --------------------------------------------------------

--
-- Structure de la table `Movie`
--

CREATE TABLE `Movie` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` int DEFAULT NULL,
  `length` int DEFAULT NULL,
  `description` text,
  `director` varchar(255) DEFAULT NULL,
  `id_category` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `trailer` varchar(255) DEFAULT NULL,
  `min_age` int DEFAULT NULL,
  `recommened` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `Movie`
--

INSERT INTO `Movie` (`id`, `name`, `year`, `length`, `description`, `director`, `id_category`, `image`, `trailer`, `min_age`, `recommened`) VALUES
(7, 'Interstellar', 2014, 169, 'Un groupe d\'explorateurs voyage à travers un trou de ver pour sauver l\'humanité.', 'Christopher Nolan', 4, 'interstellar.jpg', 'https://www.youtube.com/embed/VaOijhK3CRU?si=76Ke4uw4LYjuLuQ6', 12, 1),
(12, 'La Liste de Schindler', 1993, 195, 'Un industriel allemand sauve des milliers de Juifs pendant l\'Holocauste.', 'Steven Spielberg', 3, 'schindler.webp', 'https://www.youtube.com/embed/ONWtyxzl-GE?si=xC3ASGGPy5Ib-aPn', 16, 1),
(17, 'Your Name', 2016, 107, 'Deux adolescents échangent leurs corps de manière mystérieuse.', 'Makoto Shinkai', 5, 'your_name.jpg', 'https://www.youtube.com/embed/AROOK45LXXg?si=aUQyGk2VMCb_ToUL', 10, 1),
(27, 'Le Bon, la Brute et le Truand', 1966, 161, 'Trois hommes se lancent à la recherche d\'un trésor caché.', 'Sergio Leone', 8, 'bon_brute_truand.jpg', 'https://www.youtube.com/embed/WA1hCZFOPqs?si=TwNZAoM4oj4KpGja', 12, 1),
(49, 'Minecraft, le film', 2025, 101, 'Bienvenue dans l’univers de Minecraft où la créativité est essentielle à la survie ! Quatre outsiders – Garrett, Henry, Natalie et Dawn – sont soudainement projetés à travers un mystérieux portail menant à La Surface – un incroyable monde cubique qui prospère grâce à l’imagination. Pour rentrer chez eux, il leur faudra maîtriser ce monde (et le protéger de créatures maléfiques comme les Piglins et les Zombies), tout en s’engageant dans une quête fantastique aux côtés de Steve, expert fabricateur. Cette aventure les poussera à être audacieux et à développer leur créativité. Autant de facultés dont ils auront besoin pour s’épanouir dans le monde réel.', 'Jared Hess', 8, 'minecraft.jpg', 'https://www.youtube.com/embed/E9slRynYcmI?si=qcF8oqP_Rx0CSbQo', 8, NULL),
(50, 'Titanic', 1997, 194, 'En 1997, l\'épave du Titanic est l\'objet d\'une exploration fiévreuse, menée par des chercheurs de trésor en quête d\'un diamant bleu qui se trouvait à bord. Frappée par un reportage télévisé, l\'une des rescapées du naufrage, âgée de 102 ans, Rose DeWitt, se rend sur place et évoque ses souvenirs. 1912. Fiancée à un industriel arrogant, Rose croise sur le bateau un artiste sans le sou.', 'James Cameron', 3, 'titanic.jpg', 'https://www.youtube.com/embed/ezH2c6L8lQM?si=oZprlpMHkjR0NY_u', 10, NULL),
(51, 'Le Garçon au pyjama rayé', 2008, 90, 'Bruno a tout juste 9 ans lorsque son père, un officier nazi remarqué par le Führer, se voit confier le commandement du camp de concentration d\'Auschwitz. Le petit garçon n\'apprécie guère de devoir quitter la belle et grande maison de Berlin pour se retrouver dans une demeure isolée et triste. De sa chambre, il aperçoit des hommes, des femmes et des enfants tous vêtus de pyjamas rayés. Personne ne lui explique qui ils sont, mais l\'innocence aidant, il va se lier d\'amitié avec un enfant juif...', 'Mark Herman', 3, 'le_garçon_au_pyjama_rayé.jpg', 'https://www.youtube.com/embed/f7gmjW_CkE4?si=FinHNXhOuheNIUMA', 12, NULL),
(52, 'La Ligne verte', 1999, 189, 'Paul Edgecomb, pensionnaire centenaire d\'une maison de retraite, est hanté par ses souvenirs. Gardien-chef du pénitencier de Cold Mountain, en 1935, en Louisiane, il était chargé de veiller au bon déroulement des exécutions capitales au bloc E (la ligne verte) en s\'efforçant d\'adoucir les derniers moments des condamnés. Parmi eux se trouvait un colosse du nom de John Coffey, accusé du viol et du meurtre de deux fillettes.', 'Frank Darabont', 3, 'la_ligne_verte.jpg', 'https://www.youtube.com/embed/mccs8Ql8m8o?si=k3ch_YFkA9_UeeUE', 12, NULL),
(53, 'Jurassic Park', 1993, 127, 'Ne pas réveiller le chat qui dort -- c\'est ce que le milliardaire John Hammond aurait dû se rappeler avant de se lancer dans le clonage de dinosaures. C\'est à partir d\'une goutte de sang absorbée par un moustique fossilisé que John Hammond et son équipe ont réussi à faire renaître une dizaine d\'espèces de dinosaures. Il s\'apprête maintenant avec la complicité du docteur Alan Grant, paléontologue de renom, et de son amie Ellie, à ouvrir le plus grand parc à thème du monde.', 'Steven Spielberg', 8, 'jurassic_park.jpg', 'https://www.youtube.com/embed/7cCbj-9Ww1o?si=jDjEBKSdOQMLNMS1', 10, NULL),
(54, 'Le Chat Potté 2 : la dernière quête', 2022, 102, 'Le Chat botté découvre que sa passion pour l\'aventure et son mépris du danger lui ont coûté cher : il a épuisé huit de ses neuf vies sans s\'en rendre compte. Afin de se remettre sur pied, notre héros poilu se lance littéralement dans la quête de sa vie. Il s\'embarque dans une aventure épique aux confins de la Forêt Noire afin de dénicher la mythique étoile magique, la seule chose qui puisse lui rendre ses vies perdues.', 'Joel Crawford', 5, 'le_chat_potté.jpg', 'https://www.youtube.com/embed/5fZ5hVKw2tg?si=lCHa67zAMy9SmFjP', 11, NULL),
(55, 'Dune, deuxième partie', 2024, 166, 'Paul Atréides se rallie à Chani et aux Fremen tout en préparant sa revanche contre ceux qui ont détruit sa famille. Alors qu\'il doit faire un choix entre l\'amour de sa vie et le destin de la galaxie, il devra néanmoins tout faire pour empêcher un terrible futur que lui seul peut prédire.', 'Denis Villeneuve', 1, 'dune.jpg', 'https://www.youtube.com/embed/SUfv36bB5jA?si=h5trcEY3su64d_93', 13, NULL),
(56, 'Le Seigneur des anneaux', 2001, 178, 'Un jeune et timide hobbit, Frodon Sacquet, hérite d\'un anneau magique. Sous ses apparences de simple bijou, il s\'agit en réalité d\'un instrument de pouvoir absolu qui permettrait à Sauron, le Seigneur des ténèbres, de régner sur la Terre du Milieu et de réduire en esclavage ses peuples. Frodon doit parvenir, avec l\'aide de la Communauté de l\'Anneau, composée de huit compagnons venus de différents royaumes, jusqu\'à la Montagne du Destin pour le détruire.', 'Peter Jackson', 9, 'le_seigneur_des_anneaux.jpg', 'https://www.youtube.com/embed/_nZdmwHrcnw?si=q5LdJ5caW6R3YA4p', 10, NULL),
(57, 'Alien, le huitième passager', 1979, 117, 'Durant le voyage de retour d\'un immense cargo spatial en mission commerciale de routine, ses passagers, cinq hommes et deux femmes plongés en hibernation, sont tirés de leur léthargie dix mois plus tôt que prévu par Mother, l\'ordinateur de bord. Ce dernier a en effet capté dans le silence interplanétaire des signaux sonores, et suivant une certaine clause du contrat de navigation, les astronautes sont chargés de prospecter tout indice de vie dans l\'espace.', 'Ridley Scott', 4, 'alien.jpg', 'https://www.youtube.com/embed/jQ5lPt9edzQ?si=z9Fwh4Elz9yUN5hJ', 15, NULL),
(58, 'Tenet', 2020, 150, 'Muni d\'un seul mot, \"Tenet,\" et décidé à se battre pour sauver le monde, un homme sillonne l\'univers crépusculaire de l\'espionnage international. Sa mission le projettera dans une dimension qui dépasse le temps. Pourtant, il ne s\'agit pas d\'un voyage dans le temps, mais d\'un renversement temporel.', 'Christopher Nolan', 4, 'tenet.jpg', 'https://www.youtube.com/embed/6UG5LJQNjts?si=pXVeth5YbqeVCL0t', 12, NULL),
(59, 'La Soupe aux choux', 1981, 98, 'Le Claude et Le Bombé vivent dans un petit hameau. Le premier est veuf, le second célibataire. Ensemble, ils passent la plupart de leur temps à trinquer. Une nuit, un extraterrestre atterrit dans le champ de Claude. Il ne semble pas agressif. Le Bombé est réveillé, lui aussi, par la lumière émise par la soucoupe, mais l\'extraterrestre, que Le Claude surnommera \"La Denrée,\" le paralyse sur place.', 'Jean Girault', 4, 'la_soupe_au_choux.jpg', 'https://www.youtube.com/embed/pp1Z9RfA9FY?si=QGCfotsz-hXMMFfM', 8, NULL),
(60, 'Harry Potter à l\'école des sorciers', 2001, 152, 'Harry Potter, un jeune orphelin, est élevé par son oncle et sa tante qui le détestent. Alors qu\'il était haut comme trois pommes, ces derniers lui ont raconté que ses parents étaient morts dans un accident de voiture. Le jour de son onzième anniversaire, Harry reçoit la visite inattendue d\'un homme gigantesque se nommant Rubeus Hagrid, et celui-ci lui révèle qu\'il est en fait le fils de deux puissants magiciens et qu\'il possède lui aussi d\'extraordinaires pouvoirs.', 'Chris Columbus', 9, 'harry_potter.jpg', 'https://www.youtube.com/embed/P1BGgqhVGAI?si=nyklAH75J5_e9rrm', 10, NULL),
(61, 'Mad Max: Fury Road', 2015, 120, 'Hanté par un lourd passé, Mad Max estime que le meilleur moyen de survivre est de rester seul. Cependant, il se retrouve embarqué par une bande qui parcourt la Désolation à bord d\'un véhicule militaire piloté par l\'Imperator Furiosa. Ils fuient la Citadelle où sévit le terrible Immortan Joe qui s\'est fait voler un objet irremplaçable. Enragé, ce Seigneur de guerre envoie ses hommes pour traquer les rebelles impitoyablement.', 'George Miller', 1, 'madmax.jpg', 'https://www.youtube.com/embed/hEJnMQG9ev8?si=T9yTs_fUN57KspGL', 12, 0),
(62, 'Pacific Rim', 2013, 131, 'Après avoir provoqué des millions de morts lors d\'une guerre et pillé les ressources naturelles de l\'humanité, les Kaijus, des monstres géants surgis des mers, règnent sur le monde. Pour les vaincre, des robots appelés Jaegers ont été élaborés.', 'Guillermo del Toro', 1, 'pacific_rim.jpg', 'https://www.youtube.com/embed/qOX_O118N7k?si=m4hS_tfS787zHBf6', 10, NULL),
(63, 'Rambo', 1982, 93, 'Revenu du Viêtnam, abruti autant par les mauvais traitements que lui ont jadis infligés ses tortionnaires que par l\'indifférence de ses concitoyens, le soldat Rambo, un ancien des commandos d\'élite, traîne sa redoutable carcasse de ville en ville. Un shérif teigneux lui interdit l\'accès de sa bourgade. Rambo insiste. Il veut seulement manger. Le shérif le met sous les verrous et laisse son adjoint brutaliser ce divertissant clochard.', 'Ted Kotcheff', 1, 'rambo.jpg', 'https://www.youtube.com/embed/WY9Bemk9oF0?si=dwSsZp9bIEermbT1', 12, NULL),
(64, 'Ça', 2017, 135, 'À Derry, dans le Maine, sept gamins ayant du mal à s\'intégrer se sont regroupés au sein du Club des Ratés. Rejetés par leurs camarades, ils sont les cibles favorites des gros durs de l\'école. Ils ont aussi en commun d\'avoir éprouvé leur plus grande terreur face à un terrible prédateur métamorphe qu\'ils appellent Ça.', 'Andrés Muschietti', 7, 'ca.jpg', 'https://www.youtube.com/embed/0zkm6IPr3Jw?si=3Q-JqT9SROjFcfsG', 12, NULL),
(65, ' The Thing', 1982, 109, 'Hiver 1982 au coeur de l\'Antarctique. Une équipe de chercheurs composée de 12 hommes découvre un corps enfoui sous la neige depuis plus de 100 000 ans. Décongelée, la créature retourne à la vie en prenant la forme de celui qu\'elle veut; dès lors, le soupçon s\'installe entre les hommes de l\'équipe. Un véritable combat s\'engage.', 'John Carpenter', 7, 'the_thing.jpg', 'https://www.youtube.com/embed/4NTs0mVhsv8?si=EwIo4oZeiSRd0u_Z', 12, NULL),
(66, 'Evil Dead Rise', 2023, 97, 'Les retrouvailles de deux sœurs sont interrompues par l\'apparition de démons possesseurs de chair, les plongeant dans une bataille primitive pour leur survie et les confrontant à la version la plus cauchemardesque de la famille.', 'Lee Cronin', 7, 'evil_dead.jpg', 'https://www.youtube.com/embed/BqQNO7BzN08?si=5uHdW0TxyvXD-9Gq', 16, NULL),
(67, 'Les Tuche', 2011, 95, 'Une famille modeste, les Tuche, gagne 100 millions d’euros au loto et décide de s’installer à Monaco, provoquant des situations aussi cocasses qu’inattendues.', 'Olivier Baroux', 2, 'les_tuche.jpg', 'https://www.youtube.com/embed/6U2DN2cPD4s', 10, NULL),
(68, 'Seven', 1995, 127, 'Deux détectives traquent un tueur en série qui choisit ses victimes en fonction des sept péchés capitaux.', 'David Fincher', 6, 'seven.jpg', 'https://www.youtube.com/embed/znmZoVkCjpI', 16, NULL),
(69, 'Les Dents de la mer', 1975, 124, 'Un gigantesque requin blanc terrorise les plages d\'une petite station balnéaire, poussant le chef de la police à s’associer à un biologiste marin et un chasseur de requins pour l’arrêter.', 'Steven Spielberg', 7, 'jaws.jpg', 'https://www.youtube.com/embed/U1fu_sA7XhE', 12, NULL),
(70, 'Avatar 2 : La Voie de l\'Eau', 2022, 192, 'Jake Sully et Neytiri vivent paisiblement sur Pandora avec leurs enfants. Lorsque de nouvelles menaces émergent, ils sont forcés de quitter leur maison pour explorer les océans de Pandora et se réfugier dans des tribus maritimes. Ce film continue l’histoire de la lutte pour la survie sur cette planète fascinante et pleine de dangers.', 'James Cameron', 1, 'avatar_2.jpg', 'https://www.youtube.com/embed/d9MyW72ELq0?si=LOMaoTH75CNLUT6O', 12, NULL),
(72, 'Koyaanisqatsi', 1982, 87, 'Koyaanisqatsi est un film expérimental qui explore les relations entre l\'homme, la nature et la technologie. Ce documentaire visuel, sans dialogues, présente des images de paysages naturels contrastées avec des scènes de la vie urbaine, le tout accompagné de la bande-son emblématique de Philip Glass. Le titre \"Koyaanisqatsi\" signifie \"vie en déséquilibre\" dans la langue hopi, et le film illustre la manière dont la civilisation moderne perturbe l\'harmonie du monde naturel.', 'Godfrey Reggio', 10, 'koyaanisqatsi.jpg', 'https://www.youtube.com/embed/sfUADz6wJb0', 12, NULL),
(74, 'Moi, moche et méchant', 2010, 95, 'Gru est un super-méchant qui rêve de commettre le plus grand vol de tous les temps : dérober la Lune. Avec l’aide de ses fidèles Minions, il met au point un plan machiavélique. Mais tout bascule lorsqu\'il rencontre trois petites orphelines qui, loin d’être effrayées par lui, voient en lui une figure paternelle. Au fur et à mesure qu’il passe du temps avec elles, Gru commence à changer et à redécouvrir ce que signifie l\'amour et la famille. Sa vie de super-vilain est bouleversée alors qu\'il tente de jongler entre ses ambitions et sa nouvelle responsabilité envers les filles.', 'Pierre Coffin', 5, 'moi_moche_et_mechant.jpg', 'https://www.youtube.com/embed/OPf1YYSKxBs?si=SQ5Xv-ram4GpZlTi', 1, NULL),
(75, 'RRRrrrr!!!', 2004, 98, 'Il y a 37 000 ans, deux tribus voisines vivaient en paix... à un cheveu près. La tribu des Cheveux Propres détient le secret de la formule du shampooing, tandis que la tribu des Cheveux Sales se lamente. Pour la première fois dans l\'histoire de l\'humanité, un crime est commis, bouleversant la vie des Cheveux Propres. Ce thriller préhistorique mêle humour et enquête policière sur fond de rivalités capillaires.', 'Alain Chabat', 2, 'RRRrrrr!!!.jpg', 'https://www.youtube.com/embed/y_UKPVezalU?si=qHYoDFgCFr0fZfj5', 2, NULL),
(76, 'La Grande Vadrouille', 1966, 124, 'En 1942, pendant l\'Occupation allemande, un bombardier britannique est abattu au-dessus de Paris. Trois des aviateurs parviennent à s\'échapper et sont aidés par deux civils français : Augustin Bouvet, un peintre en bâtiment, et Stanislas Lefort, un chef d\'orchestre. Ensemble, ils tentent de rejoindre la zone libre, déjouant les pièges tendus par les autorités allemandes. Ce périple rocambolesque est ponctué de situations comiques et de quiproquos, mettant en lumière la solidarité et le courage des personnages.', 'Gérard Oury', 2, 'la_grande_vadrouille.jpg', 'https://www.youtube.com/embed/UKE3-bS_zfw?si=2LEPnGqSqqPTOub1', 1, NULL),
(77, 'One Piece: Stampede', 2019, 101, 'Luffy et son équipage participent au Pirate Fest, un événement où pirates, corsaires, marines et l\'Armée Révolutionnaire s\'affrontent pour découvrir le trésor de Gol D. Roger. Ils se retrouvent face à Douglas Bullet, ancien membre de l\'équipage de Roger, surnommé \"l\'héritier du démon\".', 'Takashi Otsuka', 5, 'one_piece_stampede.jpg', 'https://www.youtube.com/embed/IJkpVA9m9bw?si=o1JSO1XSDpER6i6X', 2, NULL),
(78, 'Michael Jackson\'s This Is It', 2009, 113, 'Ce documentaire musical offre un aperçu exclusif des coulisses des dernières répétitions de Michael Jackson pour sa tournée \"This Is It\", prévue à Londres en 2009. Réalisé à partir de séquences capturées entre avril et juin 2009 au Staples Center et au Forum de Los Angeles, le film révèle le processus créatif de l\'artiste, de la mise en scène aux chorégraphies, en passant par les interactions avec son équipe. Conçu initialement pour ses archives personnelles, ce projet posthume témoigne de la passion et du perfectionnisme de Jackson, offrant aux fans un dernier regard sur son travail et son héritage artistique.', 'Kenny Ortega', 10, 'michael_jackson.jpg', 'https://www.youtube.com/embed/zUniG6F_RzY?si=Q5z6z43TC3wOyfbD', 1, NULL),
(79, 'Le Monde de Narnia', 2005, 143, 'Pendant la Seconde Guerre mondiale, les quatre enfants Pevensie — Lucy, Edmund, Susan et Peter — sont évacués à la campagne. En explorant le manoir où ils sont hébergés, Lucy découvre une armoire magique qui les transporte dans le monde enchanté de Narnia. Ce royaume est plongé dans un hiver éternel par la Sorcière blanche, Jadis. Selon une ancienne prophétie, l\'arrivée de deux fils d\'Adam et de deux filles d\'Ève, aidés par le lion Aslan, mettra fin à cette malédiction. Les enfants s\'engagent alors dans une aventure épique pour libérer Narnia du joug de la sorcière.', 'Andrew Adamson', 9, 'le_monde_de_narnia.jpg', 'https://www.youtube.com/embed/pYcGFLgJ8Uo?si=RrzlAKDl6Gh1Yel-', 2, NULL),
(80, 'Donnie Darko', 2001, 113, 'En octobre 1988, Donnie Darko, un adolescent intelligent mais perturbé, vit dans une banlieue paisible des États-Unis. Après avoir échappé de justesse à un accident mortel, il commence à avoir des visions d\'une créature énigmatique en costume de lapin nommée Frank. Cette entité lui annonce que la fin du monde surviendra dans 28 jours, 6 heures, 42 minutes et 12 secondes. À mesure que Donnie tente de comprendre ces visions, il est entraîné dans une spirale mêlant voyages dans le temps, troubles mentaux et questionnements existentiels.', 'Richard Kelly', 9, 'donnie_darko.jpg', 'https://www.youtube.com/embed/anaP6ZogbUY?si=C-v1qcsH-IPtl9V5', 1, NULL),
(81, 'Voyage au centre de la Terre', 2008, 93, 'Le professeur Trevor Anderson, géologue marginalisé pour ses théories audacieuses, découvre des indices laissés par son frère disparu, suggérant l\'existence d\'un monde souterrain. Accompagné de son neveu Sean et de leur guide Hannah, ils entreprennent une expédition en Islande. En suivant les traces d\'Arne Saknussemm, un explorateur du passé, ils se retrouvent propulsés dans un univers souterrain peuplé de créatures étranges et de dangers insoupçonnés. Leur périple devient une course contre la montre pour retrouver la surface et révéler au monde les secrets enfouis au cœur de la Terre.', 'Eric Brevig', 8, 'voyage_au_centre_de_la_terre.jpg', 'https://www.youtube.com/embed/ip-D1fT0PQw?si=bi_fBtOcofStb_3Q', 1, NULL),
(82, 'La Tour Montparnasse infernale', 2001, 92, 'Un soir, suspendus au 52e étage de la Tour Montparnasse, Éric et Ramzy, deux laveurs de carreaux, prennent du retard dans leur travail. Pendant ce temps, Stéphanie attend son oncle, le PDG du Groupe Lanceval, et ses fils pour un conseil d\'administration nocturne. Un commando armé investit alors l\'immeuble, prend la famille en otage et verrouille tous les accès. Stéphanie, en réalité l\'organisatrice du coup, vise la fortune de son oncle qui la méprise. Éric et Ramzy, naïfs et peu futés, se retrouvent mêlés à cette prise d\'otages et tentent de sauver la situation malgré eux.', 'Charles Nemes', 2, 'la_tour_montparnasse_infernale.jpg', 'https://www.youtube.com/embed/UKE3-bS_zfw?si=JRnzGloF-nP6mFc3', 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `Utilisateur`
--

CREATE TABLE `Utilisateur` (
  `id` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `avatar` varchar(250) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `age` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `Utilisateur`
--

INSERT INTO `Utilisateur` (`id`, `name`, `avatar`, `age`) VALUES
(3, 'Kids', 'avatar_spongebob.jpg', '2020-01-01'),
(55, 'Lilian', 'avatar_chat.jpg', '2006-06-23'),
(56, 'Addem Bzzz', '', '2001-02-20');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Favorite`
--
ALTER TABLE `Favorite`
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_movie` (`id_movie`);

--
-- Index pour la table `Movie`
--
ALTER TABLE `Movie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_category` (`id_category`);

--
-- Index pour la table `Utilisateur`
--
ALTER TABLE `Utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Category`
--
ALTER TABLE `Category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `Movie`
--
ALTER TABLE `Movie`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT pour la table `Utilisateur`
--
ALTER TABLE `Utilisateur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Favorite`
--
ALTER TABLE `Favorite`
  ADD CONSTRAINT `Favorite_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `Utilisateur` (`id`),
  ADD CONSTRAINT `Favorite_ibfk_2` FOREIGN KEY (`id_movie`) REFERENCES `Movie` (`id`);

--
-- Contraintes pour la table `Movie`
--
ALTER TABLE `Movie`
  ADD CONSTRAINT `movie_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `Category` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
